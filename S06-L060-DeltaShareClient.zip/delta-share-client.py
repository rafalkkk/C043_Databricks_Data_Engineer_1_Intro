import delta_sharing
import pandas as pd

# Read the profile
profile_file = "config.share"
client = delta_sharing.SharingClient(profile_file)

# List table
tables = client.list_all_tables()
for table in tables:
    print(f"Table: {table.name}")

# Select one table
table_url = f"{profile_file}#weather_gold.weather.avg_temperatures"

# Get data into DataFrame
df = delta_sharing.load_as_pandas(table_url)

# Print data
print(df.head())
